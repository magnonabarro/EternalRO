// Copyright (c) rAthena Dev Teams - Licensed under GNU GPL
// For more information, see LICENCE in the main folder

#include "divinusflos.hpp"

#include <config/core.hpp>

#include "map/clif.hpp"
#include "map/pc.hpp"
#include "map/status.hpp"

SkillDivinusFlos::SkillDivinusFlos() : SkillImplRecursiveDamageSplash(CD_DIVINUS_FLOS) {
}

void SkillDivinusFlos::calculateSkillRatio(const Damage* wd, const block_list* src, const block_list* target, uint16 skill_lv, int32& skillratio, int32 mflag) const {
	const map_session_data* sd = BL_CAST(BL_PC, src);
	const status_data* sstatus = status_get_status_data(*src);

	skillratio += -100 + 4000 * skill_lv;
	skillratio += 70 * pc_checkskill(sd, CD_FIDUS_ANIMUS);
	skillratio += 10 * sstatus->spl;
	RE_LVL_DMOD(100);
}

void SkillDivinusFlos::splashSearch(block_list* src, block_list* target, uint16 skill_lv, t_tick tick, int32 flag) const {
	clif_skill_nodamage(src, *target, getSkillId(), skill_lv);

	SkillImplRecursiveDamageSplash::splashSearch(src, target, skill_lv, tick, flag);
}

void SkillDivinusFlos::modifyElement(const Damage& dmg, const block_list& src, const block_list& target, uint16 skill_lv, int32& element, int32 flag) const {
	const status_change* sc = status_get_sc(&src);

	if (sc != nullptr && sc->hasSCE(SC_ANCILLA))
		element = ELE_NEUTRAL;
}
